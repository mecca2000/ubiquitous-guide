用户指定：只要进行联网搜索，优先使用 searxng skill。
